/*
 * To change this license header, choose License Headers in
Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br;
/**
 *
 * @author lucio
 */
public class Principal {
 public static void main(String[] args) {
 System.out.println("Principal: envia mensagem para oservidor");

 String soapEndpointUrl =
"http://localhost:8080/WSServer/SomaService?wsdl";
 String soapAction =
"http://localhost:8080/WSServer/SomaService";
 //Soma 1+2
 int c1=1;
 int c2=2;
 String CAMPO1 = String.valueOf(c1);
 String CAMPO2 = String.valueOf(c2);

 SoapClient sc = new SoapClient(CAMPO1,CAMPO2);
 sc.callSoapWebService(soapEndpointUrl, soapAction);
 System.out.println("Fim!");
 }
} 