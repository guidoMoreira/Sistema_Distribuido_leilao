//Exemplo de sala

package br.ws;

import jakarta.jws.WebService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;

/**
 *
 * @author root
 */
@WebService(serviceName = "SomaService")
public class SoapService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello      " + txt + " !";
    }

    @WebMethod(operationName = "somar")
    public int somar(@WebParam(name = "campo1") String CAMPO1, @WebParam(name = "campo2") String CAMPO2) {
        return Integer.parseInt(CAMPO1) + Integer.parseInt(CAMPO2);
    }
}
